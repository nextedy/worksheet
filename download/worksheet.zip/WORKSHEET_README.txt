com.nextedy.polarion.worksheet
===========================
Detailed README: com.nextedy.polarion.worksheet/README.txt
Installation instructions: com.nextedy.polarion.worksheet/INSTALL.txt
Licensing information: com.nextedy.polarion.worksheet/LICENSE.pdf

